A simple clone of the snake game, developed as my first attempt at using `canvas` and Javascript.

It was originally intended for the [0hgame jam](http://0hgame.eu), but couldn't make it on time. 

You could try it live before, but it doesn't work in modern browsers anymore.

Thankful mention to [Bill Mill's tutorial](http://billmill.org/static/canvastutorial/), my starting point.
